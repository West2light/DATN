GÓI MINH CHỨNG MÃ NGUỒN - ĐỒ ÁN TỐT NGHIỆP
Sinh viên: Dương Quang Đông - MSSV 20225808
Đề tài: Multi-Agent Pathfinding (MAPF) trong game tank 2D (Unity)

Gói này chỉ chứa MÃ NGUỒN và DỮ LIỆU THỰC NGHIỆM (không kèm báo cáo, không kèm
ảnh/biểu đồ, không kèm thư viện build) nhằm gọn dung lượng.

CẤU TRÚC:

01_MaNguon_Game_Unity/   Mã nguồn dự án game Unity (chỉ phần do sinh viên viết)
   Assets/Scripts/         Toàn bộ mã C#: MapLoader, A*, PIBT C#, PIBT TCP,
                           backtest, multiplayer, điều khiển tank...
   Assets/Scenes/          Scene Unity (MapF_TankTest...)
   Assets/Docs/            Tài liệu kỹ thuật (tiếng Việt)
   Assets/MapData/         Bản đồ benchmark MAPF (.map)
   Assets/Data/            ScriptableObject cấu hình (tank, bullet, turret)
   Assets/Prefabs/         Prefab
   Assets/Editor/          Script editor
   ProjectSettings/        Cấu hình dự án Unity (phiên bản, layer, physics)
   Packages/manifest.json  Danh sách package phụ thuộc
   (Không kèm: Library/, Builds/, Sprites/Audio bên thứ ba)

02_Server_PIBT_Cpp/      Mã nguồn máy chủ PIBT C++ (chạy trên WSL/Ubuntu)
   src/  inc/             Mã nguồn và header C++
   default_planner/       Planner mặc định
   python/  app.py        Lớp giao tiếp / proxy TCP (tcp_proxy.py)
   CMakeLists.txt         Cấu hình build CMake
   *.md                   Tài liệu định dạng I/O, môi trường đánh giá
   (Không kèm: build/, .git/, example_problems/, image/)

03_KetQua_CSV/           Dữ liệu thực nghiệm thô (CSV) từ công cụ Backtest
   backtest_summary_*.csv   Tổng hợp mỗi lượt chạy (thời gian, replan, recovery...)
   backtest_agents_*.csv    Chi tiết theo từng agent
   report_scaling_*.csv     Tổng hợp theo số agent / theo bản đồ
